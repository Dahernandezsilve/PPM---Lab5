package com.example.affirmations.data

import com.example.affirmations.R
import com.example.affirmations.model.Affirmation


class DataSource {



    fun loadAffirmations(): List<Affirmation>{
        return listOf<Affirmation>(
            Affirmation(R.string.affirmation1, R.string.image1),
            Affirmation(R.string.affirmation2, R.string.image2),
            Affirmation(R.string.affirmation3, R.string.image3),
            Affirmation(R.string.affirmation4, R.string.image4),
            Affirmation(R.string.affirmation5, R.string.image5),
            Affirmation(R.string.affirmation6, R.string.image6),
            Affirmation(R.string.affirmation7, R.string.image7),
            Affirmation(R.string.affirmation8, R.string.image8),
            Affirmation(R.string.affirmation9, R.string.image9),
            Affirmation(R.string.affirmation10, R.string.image10)
        )
    }
}